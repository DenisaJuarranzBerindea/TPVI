#include "Koopa.h"

Koopa::Koopa()
{

}

void Koopa::render() const
{

}

void Koopa::update()
{

}

void Koopa::hit(SDL_Rect* rect)
{

}