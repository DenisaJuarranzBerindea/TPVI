#include "Mushroom.h"

Mushroom::Mushroom()
{

}

void Mushroom::render() const
{

}

void Mushroom::update()
{

}

void Mushroom::hit(SDL_Rect* rect)
{

}